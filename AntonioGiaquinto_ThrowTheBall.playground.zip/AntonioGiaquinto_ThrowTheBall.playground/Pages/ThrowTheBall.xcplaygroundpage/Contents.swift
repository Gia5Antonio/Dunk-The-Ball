/*:
 # Playground - noun: a place where people can play
 - - -
 */

//: ## Import of the lybraries which is needed for this little game.
import UIKit
import PlaygroundSupport
import SpriteKit

//: ## Creation of the frame where all appens. It adapt itselves to the screen dimensions where the playground is running.
//let frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)

//: ### This type of frame have always the same dimension wherever the code is running. It is used only to try the playground on the mac.
let frame = CGRect(x: 0, y: 0, width: 500, height: 700)

//: ## Creation of the view that contains the frame.
let container = SKView(frame: frame)

//: ## Creation of the scene.
let scene = Scene()

//: ## Presentation of the scene and liveView creation
container.presentScene(scene)
PlaygroundPage.current.liveView = container

//: # NOW IT'S TIME TO PLAY!!

