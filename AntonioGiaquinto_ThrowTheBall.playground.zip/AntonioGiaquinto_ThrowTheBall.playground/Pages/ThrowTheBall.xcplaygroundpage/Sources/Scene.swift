import Foundation
import SpriteKit
import AVFoundation

let dimScene = CGSize(width: 500, height: 700)
let dimGameOver = CGSize(width: 480, height: 500)
let physicFrame = CGRect(x: 0, y: 0, width: 500, height: 2500)
let ballCategory: UInt32 = 1
let detectorCategory: UInt32 = 2
let floorCategory: UInt32 = 3
let ringCategory: UInt32 = 5

public class Scene: SKScene, SKPhysicsContactDelegate {
    var ballTouched: Bool = false//This variable indicates if the ball is touched or not
    var isScoring: Bool = false  //This variable indicates if the player has done a point
    var moveLeft: Bool = false   //This variable indicates if the board are moving
    var moveUp: Bool = false     //This variable indicates if the board are moving
    var gameEnded: Bool = false  //This variable indicates if the game ended (the time is over)
    
    var prevTouchTimestamp: TimeInterval = 0.0
    var ballSpeed: Double = 0.0  //This variable indicates the ball speed
    var score: Int = 0           //This variable indicates the score
    
    var bouncePlayer: AVAudioPlayer?//This variable indicates the sound associated to the bounce
    var rimPlayer: AVAudioPlayer?   //This variable indicates the sound associated to the rim
    var musicPlayer: AVAudioPlayer?
    
    var timerValue: Int = 0
    let gameOverWindow = SKShapeNode(rectOf: dimGameOver, cornerRadius: 20)
    let gameOverLabel = SKLabelNode(fontNamed: "Futura-Medium")
    let restartButton = SKLabelNode(fontNamed: "Futura-Medium")
    
    // Variables releated to the pricipal scene (game Scene)
    let basketCourt = SKSpriteNode(imageNamed: "basketCourt.png")
    let board = SKSpriteNode(imageNamed: "board.png")
    let ring = SKSpriteNode(imageNamed: "Ring.png")
    let net = SKSpriteNode(imageNamed: "net.png")
    let detector = SKSpriteNode(color: .clear, size: CGSize(width: 68, height: 5))
    let limit = SKSpriteNode(color: .white, size: CGSize(width: dimScene.width, height: 1))
    let ball = SKSpriteNode(imageNamed: "ball.png")
    let scoreLabel = SKLabelNode(text: "SCORE: 0")
    let timerLabel = SKLabelNode(text: "Time left: 15")
    
    let sxExtreme = SKSpriteNode(color: .clear, size: CGSize(width: 3, height: 3))
    let dxExtreme = SKSpriteNode(color: .clear, size: CGSize(width: 3, height: 3))
    
    required public override init() {
        super.init(size: dimScene)
        self.physicsBody = SKPhysicsBody(edgeLoopFrom: physicFrame)
        self.physicsBody?.categoryBitMask = floorCategory
        self.physicsWorld.gravity = CGVector(dx: 0, dy: -0.5)
        self.physicsWorld.speed = 5
        self.createScene()
    }
    
    // MARK: Creation of principal scene (game Scene)
    public func createScene() {
        //Declaration of the node
        ball.name = "Ball"
        board.name = "BoardNode"
        ring.name = "BoardNode"
        detector.name = "BoardNode"
        net.name = "BoardNode"
        
        sxExtreme.name = "BoardNode"
        dxExtreme.name = "BoardNode"
        
        scoreLabel.name = "Score"
        timerLabel.name = "Timer"
        
        //Dimension of the node
        ball.size = CGSize(width: 60, height: 60)
        board.size = CGSize(width: 300, height: 187.5)
        ring.size = CGSize(width: 104.25, height: 5.25)
        net.size = CGSize(width: 98.25, height: 74.25)
        
        //Position of the node
        ball.position = CGPoint(x: self.size.width/2, y: ball.frame.size.height/2)
        board.position.x = self.frame.width/2
        board.position.y = self.frame.height - 200
        ring.position.x = self.frame.width/2
        ring.position.y = board.position.y - 78
        detector.position = ring.position
        net.position.x = self.frame.width/2
        net.position.y = ring.position.y - 37
        limit.position.x = self.frame.width/2
        limit.position.y = self.frame.height/2
        sxExtreme.position.x = ring.position.x - ring.size.width/2
        sxExtreme.position.y = ring.position.y
        dxExtreme.position.x = ring.position.x + ring.size.width/2
        dxExtreme.position.y = ring.position.y
        basketCourt.position.x = self.frame.size.width/2
        basketCourt.position.y = self.frame.size.height/2
        
        scoreLabel.position.x = self.frame.width/2
        scoreLabel.position.y = board.position.y + board.frame.size.height/2 + 20
        timerLabel.position.x = self.frame.width/2
        timerLabel.position.y = self.frame.height - 50
        
        //zPosition of the node
        ring.zPosition = CGFloat(integerLiteral: 1)
        detector.zPosition = CGFloat(integerLiteral: 2)
        net.zPosition = CGFloat(integerLiteral: 1)
        
        //Physic of the node
        ball.physicsBody = SKPhysicsBody(circleOfRadius: 30)
        detector.physicsBody = SKPhysicsBody(rectangleOf: detector.size)
        sxExtreme.physicsBody = SKPhysicsBody(circleOfRadius: 1.5)
        dxExtreme.physicsBody = SKPhysicsBody(circleOfRadius: 1.5)
        
        ball.physicsBody?.categoryBitMask = ballCategory
        detector.physicsBody?.categoryBitMask = detectorCategory
        sxExtreme.physicsBody?.categoryBitMask = ringCategory
        dxExtreme.physicsBody?.categoryBitMask = ringCategory
        
        ball.physicsBody?.collisionBitMask = 1
        detector.physicsBody?.collisionBitMask = 0
        
        ball.physicsBody?.contactTestBitMask = detectorCategory
        detector.physicsBody?.contactTestBitMask = ballCategory
        sxExtreme.physicsBody?.contactTestBitMask = ballCategory
        dxExtreme.physicsBody?.contactTestBitMask = ballCategory
        
        sxExtreme.physicsBody?.isDynamic = false
        dxExtreme.physicsBody?.isDynamic = false
        
        ball.physicsBody?.restitution = 0.8
        ball.physicsBody?.friction = 0.5
        
        detector.physicsBody?.affectedByGravity = false
        
        //Score & Timer Label
        scoreLabel.text = "SCORE: \(score)"
        scoreLabel.fontName = "Futura-Medium"
        scoreLabel.fontSize = 30
        
        timerLabel.fontName = "Futura-Medium"
        timerLabel.fontSize = 40
        timerLabel.fontColor = SKColor.white
        
        self.setTimer()
        self.timerValue = 15
        
        self.addChild(basketCourt)
        self.addChild(board)
        self.addChild(ring)
        self.addChild(sxExtreme)
        self.addChild(dxExtreme)
        self.addChild(net)
        self.addChild(limit)
        self.addChild(detector)
        self.addChild(scoreLabel)
        self.addChild(timerLabel)
        self.addChild(ball)
    }
    
    // MARK: Creation of secondary scene (gameOver Scene)
    func gameOver() {
        self.removeAllChildren()
        self.removeAllActions()
        self.gameEnded = true
        
        gameOverWindow.position.x = self.frame.width/2
        gameOverWindow.position.y = self.frame.height/2
        gameOverWindow.fillColor = SKColor.black
        
        gameOverLabel.text = "TIME UP! You have scored \(score) points"
        gameOverLabel.fontSize = 30
        gameOverLabel.position.x = gameOverWindow.position.x
        gameOverLabel.position.y = gameOverWindow.position.y + 50
        
        restartButton.text = "RESTART"
        restartButton.fontColor = UIColor.red
        restartButton.position.x = gameOverWindow.position.x
        restartButton.position.y = gameOverWindow.position.y - 50
        
        addChild(gameOverWindow)
        addChild(gameOverLabel)
        addChild(restartButton)
    }
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let location = touch.location(in: self)
            if !gameEnded {
                if ball.contains(location) {
                    self.ballTouched = true
                    self.prevTouchTimestamp = touch.timestamp
                    ball.physicsBody?.affectedByGravity = false
                    ball.physicsBody?.velocity = CGVector(dx: 0, dy: 0)
                }
            } else if restartButton.contains(location) {
                self.removeAllChildren()
                self.removeAllActions()
                self.score = 0
                self.gameEnded = false
                self.createScene()
            }
        }
    }
    
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            if self.ballTouched {
                let location = touch.location(in: self)
                if location.y > self.frame.height/2 {
                    self.touchesEnded(touches, with: event)
                    return
                }
                let prevLocation = touch.previousLocation(in: self)
                let distanceBetweenLoc = self.calcDistance(a: location, b: prevLocation)
                let timeInterval = (touch.timestamp - self.prevTouchTimestamp)
                
                self.ballSpeed = distanceBetweenLoc / (timeInterval*1000)
                
                if self.contains(location) {
                    ball.position.x = location.x
                    ball.position.y = location.y
                }
                //              print(self.ballSpeed)
                self.prevTouchTimestamp = touch.timestamp
            }
        }
    }
    
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if ballTouched {
            ballTouched = false
            if let touch = touches.first {
                let xDirection = touch.location(in: self).x - touch.previousLocation(in: self).x
                let yDirection = touch.location(in: self).y - touch.previousLocation(in: self).y
                
                ball.physicsBody?.affectedByGravity = true
                ball.physicsBody?.velocity = CGVector(dx: Double(xDirection) * self.ballSpeed, dy: Double(yDirection) * self.ballSpeed)
            }
        }
    }
    
    public override func didMove(to view: SKView) {
        self.physicsWorld.contactDelegate = self
    }
    
    public func didBegin(_ contact: SKPhysicsContact) {
        let firstBody = contact.bodyA
        let secondBody = contact.bodyB
        
        if secondBody.categoryBitMask == ballCategory && firstBody.categoryBitMask == detectorCategory{
            if Float((secondBody.node?.position.y)!) > Float((firstBody.node?.position.y)!) {
                isScoring = true
            }
        }
    }
    
    public func didEnd(_ contact: SKPhysicsContact) {
        let firstBody = contact.bodyA
        let secondBody = contact.bodyB
        
        if firstBody.categoryBitMask == floorCategory || secondBody.categoryBitMask == floorCategory {  //play bounce audio effect
            self.playSound("bounce")
        } else if firstBody.categoryBitMask == ringCategory || secondBody.categoryBitMask == ringCategory {
            self.playSound("rim")
        } else if secondBody.categoryBitMask == ballCategory && firstBody.categoryBitMask == detectorCategory{
            if isScoring && Float((secondBody.node?.position.y)!) < Float((firstBody.node?.position.y)!) {  //point scored
                isScoring = false
                score += 1
                scoreLabel.text = "SCORE: \(self.score)"
                self.playSound("Swish")
            } else {  //the ball was entering in the net but something went wrong...
                isScoring = false
            }
        }
    }
    
    // MARK: Update function
    public override func update(_ currentTime: TimeInterval) {
        self.moveBoard()
        timerLabel.text = "Time left: \(self.timerValue)"
    }
    
    // MARK: Calculation of the distance (Pythagorean theorem)
    func calcDistance(a: CGPoint, b: CGPoint) -> Double {
        var distance: Double = 0.0
        distance = sqrt( Double(pow((a.x - b.x), 2) + pow((a.y - b.y), 2)))
        return distance
    }
    
    // MARK: Movement of the board
    func moveBoard() {
        self.enumerateChildNodes(withName: "BoardNode") { (bnode, stop) in
            let board = bnode as! SKSpriteNode
            
            if self.frame.width == board.position.x + board.frame.size.width/2 {
                self.moveLeft = true
            }
            else if board.position.x - board.frame.size.width/2 == 0 {
                self.moveLeft = false
            }
            
            if self.moveLeft {
                board.position.x -= 1
            }
            else {
                board.position.x += 1
            }
        }
    }
    
    // MARK: PlaySound
    func playSound(_ audioUrl: String) {
        let url = Bundle.main.url(forResource: audioUrl, withExtension: "mp3")!
        
        do {
            if audioUrl == "bounce" {
                bouncePlayer = try AVAudioPlayer(contentsOf: url)
                guard let bouncePlayer = bouncePlayer else { return }
                
                bouncePlayer.play()
            } else {
                rimPlayer = try AVAudioPlayer(contentsOf: url)
                guard let rimPlayer = rimPlayer else { return }
                rimPlayer.play()
            }
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    // MARK: Timer
    public func setTimer() {
        let wait = SKAction.wait(forDuration: 1)
        let block = SKAction.run({
            [unowned self] in
            
            if self.timerValue > 0{
                self.timerValue -= 1
                if self.timerValue < 10 {
                    self.timerLabel.fontColor = SKColor.red
                }
            } else {
                self.removeAction(forKey: "timer")
                self.gameOver()
            }
        })
        let sequence = SKAction.sequence([wait,block])
        run(SKAction.repeatForever(sequence), withKey: "timer")
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
